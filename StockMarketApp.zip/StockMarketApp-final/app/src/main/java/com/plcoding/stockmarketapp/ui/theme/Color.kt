package com.plcoding.stockmarketapp.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBlue = Color(0xFF060D2E)
val TextWhite = Color(0xFFEEEEEE)